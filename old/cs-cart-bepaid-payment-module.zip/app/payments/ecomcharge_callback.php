<?php
//Auth : Senthil.R (senthil1975@gmail.com)


define('AREA', 'C');
define('SKIP_SESSION_VALIDATION', true);
require './../../init.php';

	$ExternalLibPath =realpath(dirname(__FILE__)).DS.'ecomChargeLib.php';
	require_once ($ExternalLibPath);

//ecomcharge
	$response = array();
	$paymentfrm = new ecomChargeLib('', '', '');			
	$paymentfrm->validateIPN();	
	$response['currency'] = $paymentfrm->GetPaymentCurrency();				
	$paymentfrm->SetCurrencyMultiplyer($response['currency']);
	$response['status'] = $paymentfrm->GetPaymentStatus();
	$response['amount'] = $paymentfrm->GetPaymentAmount();	
	$response['transid'] = $paymentfrm->GetPaymentUid();		
	$test_mode = $paymentfrm->Gettestmode();
	$PaymentType = $paymentfrm->GetPaymentType();	
	
	$test_msg = '';
	if ($test_mode == 'true') $test_msg = ' *** Test Mode ***';

	$pay_msg = '';
	if ($PaymentType == 'authorization') $pay_msg = 'Callback received. eComCharge Payment Authorized. UID:';
	else $pay_msg = 'Callback received. eComCharge Payment Captured. UID:';

	
	$order_id = $paymentfrm->GetPaymentOrderno();		

//    $order_id = $response['orderno'];
//	$order_id = $_REQUEST['order_id'];	
	$order_info = fn_get_order_info($order_id);
	$payment_id = db_get_field("SELECT payment_id FROM ?:orders WHERE order_id = ?i", $order_id);
    $processor_data = fn_get_payment_method_data($payment_id);	
	
//	$key = $processor_data['processor_params']['ecomcharge_key'];
//	$salt = $processor_data['processor_params']['ecomcharge_salt'];		



    if ($response['status'] == 'successful') {
			$pp_response['order_status'] = 'P';
			$pp_response["reason_text"] = '';		
			$pp_response["eComCharge"] = $pay_msg . $response['transid'].$test_msg ;					
			$pp_response["transaction_id"] = $response['transid'];

		} else if (!is_null($response['status'])) {
			$pp_response['order_status'] = 'F';
			$pp_response["eComCharge"] = 'Callback received. eComCharge Payment Failed. UID : ' . $response['transid'].$test_msg;
			$pp_response["reason_text"] = 'Payment Failed.';			
			$pp_response["transaction_id"] = $response['transid'];			
		}
		fn_finish_payment($order_id, $pp_response);		
//        fn_order_placement_routines('route', $order_id);		

	echo "OK";
?>