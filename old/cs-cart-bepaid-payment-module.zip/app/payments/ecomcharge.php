<?php
//Auth : Senthil.R (senthil1975@gmail.com)
use Tygh\Registry;

if ( !defined('AREA') ) { die('Access denied'); }

if (defined('PAYMENT_NOTIFICATION')) {
    if ($mode == 'notify') {
	$order_id = $_REQUEST['order_id'];	

    fn_order_placement_routines('route', $order_id);		
}
}
else{

        $order_id = $order_info['repaid'] ? $order_id . '_' . $order_info['repaid'] : $order_id;
		$shop_id = $processor_data['processor_params']['ecomcharge_shop_id'];
		$shop_pass = $processor_data['processor_params']['ecomcharge_shop_pass'];		
		$shop_mode =  $processor_data['processor_params']['ecomcharge_mode'];		
		$payment_type =  $processor_data['processor_params']['ecomcharge_payment_type'];				
		
		$state = $order_info['b_state'];
		if (empty($state)) $state_val = 'NIL'; 		
		else $state_val = $state; 		
		
	    $cancel_url = fn_url('checkout.checkout');
	    $ipn_url = Registry::get('config.http_location') . '/app/payments/ecomcharge_callback.php';	
//		$ipn_url = fn_url('/app/payments/ecomcharge_callback.php')
		

		$success_url = fn_url("payment_notification.notify?payment=ecomcharge&order_id=$order_id&transmode=success", AREA, 'http');			
		$fail_url = fn_url("payment_notification.notify?payment=ecomcharge&order_id=$order_id&transmode=fail", AREA, 'http');					
		$lang_iso_code = CART_LANGUAGE;
		$currency_code = $order_info['secondary_currency'];
		$amount = $order_info['total'];
		$description = 'Order #'.$order_id;
		$settings = array(
    	   "success_url" => $success_url, 
	      "decline_url" => $fail_url,
    	  "fail_url" => $fail_url,
	      "cancel_url" => $cancel_url,
    	  "notification_url" => $ipn_url,
	      "language"=> $lang_iso_code);
		  
		$order = array("currency" => $currency_code,
	      "amount"=> $amount,
		  "tracking_id" => $order_id,
    	  "description"=> $description)	 ;		
		  
		$customer = array(
		      "ip"=> $_SERVER['REMOTE_ADDR'],
		      "first_name"=> $order_info['b_firstname'],
		      "last_name"=> $order_info['b_lastname'],	  
		      "address"=> $order_info['b_address'],
		      "country"=> $order_info['b_country'],
		      "city"=> $order_info['b_city'],
		      "state"=> $state_val,	  
		      "zip"=> $order_info['b_zipcode'],	  
		      "phone"=> $order_info['phone'],	  			  
		      "email"=> $order_info['email']
		  );	  		
		  		

		$ExternalLibPath =realpath(dirname(__FILE__)).DS.'ecomChargeLib.php';

		require_once ($ExternalLibPath);
		
		$paymentfrm = new ecomChargeLib($shop_id, $shop_pass, $shop_mode);
		$paymentfrm->SetCurrencyMultiplyer($order['currency']);
		if ($payment_type == 'authorization') $paymentfrm->SetAuthorization();
		$order["amount"] = $amount * $paymentfrm->GetCurrencyMultiplyer();
		$paymentfrm->SetCheckoutArray("settings", $settings);
		$paymentfrm->SetCheckoutArray("order", $order);
		$paymentfrm->SetCheckoutArray("customer", $customer);
		$url = $paymentfrm->GetCheckoutUrl();
	   	
	

        echo <<<EOT
<html>
<body>

EOT;
        echo '<script type="text/javascript">window.location="'.$url.'";</script>';
        echo <<<EOT
		</form>
	</body>
</html>
<?php
EOT;
exit;
}
?>